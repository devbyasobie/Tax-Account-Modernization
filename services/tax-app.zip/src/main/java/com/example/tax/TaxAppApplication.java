package com.example.tax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxAppApplication.class, args);
	}

}
